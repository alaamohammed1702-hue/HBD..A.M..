
import React from 'react';
import { QuizQuestion } from './types';

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    question: "منو أكثر واحد حلو ومحبوب بهذا الكون؟",
    options: ["عمار", "بثكوتة", "عمار البثكوتة أكيد", "ماكو غيره"],
    correctAnswer: 3
  },
  {
    question: "شتسوي اذا اشتاقيتلي؟",
    options: ["تتصلي", "تسمع اغنية تذكرك بيه", "تشوف صورنا سوه", "كل هذني وأكثر"],
    correctAnswer: 3
  },
  {
    question: "ليش عموري دلعه \"بثكوته\"",
    options: ["لأن ملامحه تذوب القلب", "لأن طعمه حلو مثل الشكر", "لأن هو القطعة النادرة بحياتي", "كل ماسبق"],
    correctAnswer: 3
  }
];

// YouTube ID for "Fadel Chaker - Law Ala Albi"
export const MUSIC_ID = "2wZ9OrZyvPo";
export const MUSIC_URL_BASE = "https://www.youtube.com/embed/";
