
import React, { useEffect, useState } from 'react';
import FloatingHearts from './components/FloatingHearts';
import LoveQuiz from './components/LoveQuiz';
import LoveNotesGenerator from './components/LoveNotesGenerator';
import MusicPlayer from './components/MusicPlayer';
import { soundService } from './services/soundService';

type AppPhase = 'countdown' | 'celebration' | 'main';

const App: React.FC = () => {
  const [phase, setPhase] = useState<AppPhase>('countdown');
  const [time, setTime] = useState({ h: 11, m: 59, s: 50 });
  const [scrolled, setScrolled] = useState(0);
  const [startMusic, setStartMusic] = useState(false);
  const [showCopyToast, setShowCopyToast] = useState(false);

  useEffect(() => {
    if (phase === 'countdown') {
      const timer = setInterval(() => {
        soundService.playTick();
        setTime((prev) => {
          if (prev.s < 59) return { ...prev, s: prev.s + 1 };
          if (prev.m < 59) return { h: 11, m: prev.m + 1, s: 0 };
          return { h: 12, m: 0, s: 0 };
        });
      }, 1000); 

      if (time.h === 12 && time.m === 0) {
        clearInterval(timer);
        setPhase('celebration');
        soundService.playCelebration();
      }
      return () => clearInterval(timer);
    }
  }, [time, phase]);

  useEffect(() => {
    const handleScroll = () => {
      const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
      const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      setScrolled((winScroll / height) * 100);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const enterMainPhase = () => {
    setStartMusic(true);
    setPhase('main');
  };

  const copyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setShowCopyToast(true);
    setTimeout(() => setShowCopyToast(false), 3000);
  };

  if (phase === 'countdown') {
    return (
      <div 
        className="min-h-screen bg-black flex flex-col items-center justify-center text-rose-500 font-mono cursor-pointer" 
        onClick={() => soundService.playTick()}
      >
        <div className="text-8xl md:text-9xl font-bold tracking-tighter shadow-rose-500/50 drop-shadow-[0_0_20px_rgba(244,63,94,0.9)] animate-pulse">
          {String(time.h).padStart(2, '0')}:{String(time.m).padStart(2, '0')}:{String(time.s).padStart(2, '0')}
        </div>
        <div className="mt-12 flex gap-4">
          <div className="w-3 h-3 rounded-full bg-rose-600 animate-ping"></div>
          <div className="w-3 h-3 rounded-full bg-rose-600 animate-ping [animation-delay:0.3s]"></div>
          <div className="w-3 h-3 rounded-full bg-rose-600 animate-ping [animation-delay:0.6s]"></div>
        </div>
      </div>
    );
  }

  if (phase === 'celebration') {
    return (
      <div className="min-h-screen bg-[#fff5f7] flex flex-col items-center justify-center p-4 text-center overflow-hidden">
        <FloatingHearts />
        <div className="relative z-10 animate-fade-in">
          <div className="text-6xl md:text-8xl mb-4 animate-bounce">🎉 🥳 🎂</div>
          <h2 className="text-rose-500 text-5xl md:text-7xl font-bold mb-4 drop-shadow-md">
            لقد بدأت الحفلة!
          </h2>
          <div className="bg-white px-8 py-4 rounded-3xl shadow-2xl border-4 border-rose-300 inline-block mb-8 animate-pulse">
             <span className="text-4xl md:text-6xl font-bold text-rose-600">24/02/2026</span>
          </div>
          <p className="text-rose-400 text-xl md:text-2xl font-bold mb-10 max-w-md mx-auto">
             اليوم انولدت أحلى "بثكوتة" بالكون.. عمار قلبي ❤️
          </p>
          <button 
            onClick={enterMainPhase}
            className="group relative px-12 py-6 bg-rose-600 text-white rounded-full text-2xl font-bold shadow-[0_10px_40px_rgba(244,63,94,0.4)] hover:scale-110 active:scale-95 transition-all overflow-hidden"
          >
            <span className="relative z-10">ادخل عالم البثكوتة 🎁</span>
            <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform"></div>
          </button>
        </div>
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(20)].map((_, i) => (
            <div key={i} className="confetti" style={{ 
              left: `${Math.random()*100}%`, 
              backgroundColor: ['#fb7185', '#f43f5e', '#fda4af', '#fce7f3'][Math.floor(Math.random()*4)],
              animationDelay: `${Math.random()*3}s`
            }}></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative font-['Tajawal'] text-gray-900 overflow-x-hidden animate-fade-in">
      <div className="fixed top-0 right-0 h-2 bg-rose-500 z-[100] transition-all duration-300" style={{ width: `${scrolled}%` }} />
      <FloatingHearts />
      
      <MusicPlayer forcePlay={startMusic} />

      {showCopyToast && (
        <div className="fixed top-10 left-1/2 -translate-x-1/2 z-[200] bg-rose-600 text-white px-6 py-3 rounded-full shadow-2xl animate-bounce font-bold">
          تم نسخ الرابط! أرسله لـ عمار الآن ❤️
        </div>
      )}

      <section className="min-h-screen flex flex-col items-center justify-center relative z-10 px-4 text-center">
        <div className="animate-pulse mb-8">
          <div className="text-9xl drop-shadow-2xl hover:scale-110 transition-transform cursor-pointer">❤️</div>
        </div>
        <h1 className="text-5xl md:text-7xl font-extrabold text-rose-600 mb-4 font-romantic drop-shadow-lg">
          كل عام وأنت بألف خير عموري
        </h1>
        <p className="text-2xl md:text-3xl text-rose-400 font-bold mb-8">
          أحلى "بثكوتة" بالدنيا كلها! 🍪❤️
        </p>
        <div className="flex gap-4">
          <span className="text-4xl animate-bounce [animation-delay:0.1s]">🎂</span>
          <span className="text-4xl animate-bounce [animation-delay:0.2s]">🎈</span>
          <span className="text-4xl animate-bounce [animation-delay:0.3s]">🎁</span>
          <span className="text-4xl animate-bounce [animation-delay:0.4s]">✨</span>
        </div>
      </section>

      <section className="container mx-auto px-4 py-20 relative z-10">
        <div className="max-w-3xl mx-auto bg-white/40 backdrop-blur-md p-10 rounded-[3rem] border border-white/50 shadow-inner text-center">
          <h2 className="text-4xl font-bold text-rose-700 mb-6 font-romantic underline decoration-rose-200 underline-offset-8">
            بمناسبة عيد ميلادك.. يا بعد روحي
          </h2>
          <p className="text-xl text-gray-700 leading-loose italic">
            "سويتلك هالمفاجأة البسيطة لأنك تستاهل عيوني.. يا أغلى من كل الهدايا. أنت مو بس حبيبي، أنت 'بثكوتي' اللي تحلي أيامي. بهذا اليوم انولد أحلى شي بحياتي، فدوة لملامحك ولضحكتك."
          </p>
        </div>
      </section>

      <section className="py-20 bg-rose-50/50 relative z-10">
        <div className="container mx-auto">
          <h2 className="text-center text-4xl font-bold text-rose-600 mb-10 font-romantic">
            كلام غزل للبثكوتة
          </h2>
          <LoveNotesGenerator />
        </div>
      </section>

      <section className="py-20 relative z-10">
        <div className="container mx-auto px-4">
          <LoveQuiz />
        </div>
      </section>

      <footer className="py-12 bg-white text-center border-t border-rose-100 relative z-10">
        <p className="text-rose-400 font-bold mb-4">تصمم بكل حب لعيون عمار "البثكوتة"</p>
        <button 
          onClick={copyLink}
          className="mb-6 px-6 py-2 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 rounded-full text-sm font-bold transition-all active:scale-95 flex items-center gap-2 mx-auto"
        >
          <span>🔗</span> نسخ رابط الموقع للمشاركة
        </button>
        <div className="flex justify-center gap-2 text-2xl">
          <span>🍪</span>
          <span>❤️</span>
          <span>🍪</span>
        </div>
        <p className="mt-6 text-gray-400 text-xs">© 2026 - أحبك يا بعد قلبي</p>
      </footer>
    </div>
  );
};

export default App;
