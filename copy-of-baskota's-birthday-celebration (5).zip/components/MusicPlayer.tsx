
import React, { useState, useEffect, useRef } from 'react';
import { MUSIC_ID, MUSIC_URL_BASE } from '../constants';

interface MusicPlayerProps {
  forcePlay?: boolean;
}

const MusicPlayer: React.FC<MusicPlayerProps> = ({ forcePlay = false }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);

  useEffect(() => {
    if (forcePlay) {
      // بعد الضغط على الزر، نقوم بتفعيل الصوت والتشغيل
      setIsPlaying(true);
      setIsMuted(false);
    }
  }, [forcePlay]);

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  // إعدادات اليوتيوب للخلفية: autoplay, loop, playlist (مطلوب للتكرار), controls hidden
  const queryParams = new URLSearchParams({
    autoplay: '1',
    mute: isMuted ? '1' : '0',
    loop: '1',
    playlist: MUSIC_ID,
    playsinline: '1',
    controls: '0',
    enablejsapi: '1',
    origin: window.location.origin
  }).toString();

  const finalSrc = `${MUSIC_URL_BASE}${MUSIC_ID}?${queryParams}`;

  return (
    <div className="fixed bottom-6 left-6 z-[100] flex flex-col items-center gap-3">
      {/* أيقونة تفاعلية صغيرة للتحكم في كتم الصوت إذا أراد المستخدم */}
      <button
        onClick={toggleMute}
        className={`w-14 h-14 rounded-full flex items-center justify-center transition-all duration-500 shadow-xl border-2 ${
          !isMuted ? 'bg-rose-500 border-rose-300 animate-spin-slow' : 'bg-zinc-800 border-zinc-600'
        }`}
      >
        <span className="text-2xl">{isMuted ? '🔇' : '🎵'}</span>
      </button>

      {/* المشغل المخفي */}
      <div className="fixed -top-full -left-full opacity-0 pointer-events-none">
        <iframe
          width="100"
          height="100"
          src={finalSrc}
          title="Baskota Birthday BGM"
          allow="autoplay; encrypted-media"
        ></iframe>
      </div>

      <style>{`
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin-slow {
          animation: spin-slow 8s linear infinite;
        }
      `}</style>
    </div>
  );
};

export default MusicPlayer;
