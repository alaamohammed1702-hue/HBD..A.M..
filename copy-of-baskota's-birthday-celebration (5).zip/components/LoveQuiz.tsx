
import React, { useState } from 'react';
import { QUIZ_QUESTIONS } from '../constants';

const LoveQuiz: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (index: number) => {
    if (index === QUIZ_QUESTIONS[currentStep].correctAnswer) {
      setScore(score + 1);
    }

    if (currentStep < QUIZ_QUESTIONS.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setShowResult(true);
    }
  };

  const reset = () => {
    setCurrentStep(0);
    setScore(0);
    setShowResult(false);
  };

  return (
    <div className="bg-white/80 backdrop-blur-sm p-8 rounded-3xl shadow-xl border-4 border-rose-100 max-w-2xl mx-auto my-12 text-center">
      <h2 className="text-3xl font-bold text-rose-600 mb-6 font-romantic">اختبار "بثكوتة قلبي"</h2>
      
      {!showResult ? (
        <div>
          <div className="mb-8">
            <p className="text-sm text-rose-400 font-bold mb-2">سؤال {currentStep + 1} من {QUIZ_QUESTIONS.length}</p>
            <h3 className="text-xl font-bold text-gray-800">{QUIZ_QUESTIONS[currentStep].question}</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {QUIZ_QUESTIONS[currentStep].options.map((option, idx) => (
              <button
                key={idx}
                onClick={() => handleAnswer(idx)}
                className="p-4 bg-rose-50 hover:bg-rose-100 border-2 border-rose-200 rounded-xl transition-all text-gray-700 font-medium hover:scale-105 active:scale-95"
              >
                {option}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="animate-fade-in">
          <div className="text-6xl mb-4">🏆</div>
          <h3 className="text-2xl font-bold text-gray-800 mb-4">النتيجة: {score} من {QUIZ_QUESTIONS.length}</h3>
          <p className="text-rose-500 font-bold mb-6">
            {score === QUIZ_QUESTIONS.length 
              ? "والله العظيم تعرف بثكوتتك عدل! هنياله عمار بيك" 
              : "لازم تركز أكثر وية بثكوتتنا، بس هم نحبك!"}
          </p>
          <button
            onClick={reset}
            className="bg-rose-500 text-white px-8 py-3 rounded-full font-bold shadow-lg hover:bg-rose-600 transition-all active:scale-95"
          >
            نعيد الاختبار؟
          </button>
        </div>
      )}
    </div>
  );
};

export default LoveQuiz;
