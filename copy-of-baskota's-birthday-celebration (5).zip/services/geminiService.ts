
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateRomanticReason = async (name: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `اكتب رسالة رومانسية قصيرة جداً ومميزة لعمار (بثكوتة) بمناسبة عيد ميلاده.
      استخدم اللهجة العامية الحنينة حصراً وبصيغة المذكر (مثلاً: كل عام وأنت روحي وبثكوثتي، فدوة لقلبك عمار يا أحلى شي صار بدنيتي.).
      ملاحظة مهمة جداً: استخدم كلمة "بثكوثتي" بالثاء.
      الرسالة موجهة لعمار (ذكر). فقط سطر واحد أو سطرين.`,
      config: {
        temperature: 0.9,
        topP: 0.95,
      },
    });
    return response.text || "كل عام وأنت روحي وبثكوثتي، فدوة لقلبك عمار يا أحلى شي صار بدنيتي.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "كل عام وأنت روحي وبثكوثتي، فدوة لقلبك عمار يا أحلى شي صار بدنيتي.";
  }
};
